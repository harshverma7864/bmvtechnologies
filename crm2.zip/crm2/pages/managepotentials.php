<?php include '../assets/partials/_dbconnect.php'; ?>
<?php include '../assets/partials/_headers.php'; ?>
<?php include '../assets/partials/_fetchQueries.php'; ?>


<section class="section">
   <div class="sector2 shadow-sm">
  <div class="head1">
      <p>Manage Potentials</p>
      <a href="./createnwepotentials.php?status=new"><p class="btn btn-primary">Add new Potenial</p></a>
  </div>
<hr>
<form action="" class="filter-form">
    <div class="row">
        <div class="col-md-3">  
            <div class="mb-3 form-input">
                <label for="exampleInputEmail1" class="form-label">Search</label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
        </div>
        <div class="col-md-3">  
            <div class="mb-3 form-input">
            <label for="exampleInputEmail1" class="form-label">Potential owner</label>
            <select class="form-select" aria-label="Default select example">
            <option selected>select</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
        </select>
            </div>
        </div>
        <div class="col-md-3">  
            <div class="mb-3 form-input">
            <label for="exampleInputEmail1" class="form-label">Stage</label>
            <select class="form-select" aria-label="Default select example">
            <option selected>select</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
        </select>
            </div>
        </div>
        <div class="col-md-3">  
            <div class="mb-3 form-input">
            <label for="exampleInputEmail1" class="form-label">Potential type</label>
            <select class="form-select" aria-label="Default select example">
            <option selected>select</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
        </select>
            </div>
        </div>
        
        <div class="col-md-3">  
            <div class="mb-3 form-input">
                <label for="exampleInputEmail1" class="form-label">From date</label>
                <input type="Date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
        </div>
        <div class="col-md-3">  
            <div class="mb-3 form-input">
                <label for="exampleInputEmail1" class="form-label">To Date</label>
                <input type="Date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
        </div>
        <div class="col-md-3">  
            <div class="mb-3 btns py-4">
              
                <div class="btn btn-success mx-2">Apply Filter</div>
                <div class="btn btn-danger">Cancel</div>
            </div>
        </div>
        
    </div>
 
</form>


<div class="table-main py-4 px-4">
<table class="table">
  <thead>
    <tr>
      <th scope="col">Potential name</th>
      <th scope="col">Potential owner</th>
      <th scope="col">Partner name</th>
      <th scope="col">Product category</th>
      <th scope="col">Stage</th>
      <th scope="col">Region</th>
      <th scope="col">Created date</th>
      <th scope="col">Date</th>
      <th scope="col">Amount</th>
      <th scope="col">Potential status</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>

 
  <?php
    $result = getPotentials($conn);
    while ($row = mysqli_fetch_assoc($result)) {
    echo '
    <tr>
      <th scope="row">'.$row['potname'].'</th>
      <td><a href="./createnwepotentials.php?status=show&&id='.$row['appid'].'">'.$row['accname'].'</a></td>
      <td>partnername</td>
      <td>'.$row['parentcat'].'</td>
      <td>$row[stage]</td>
      <td>'.$row['region'].'</td>
      <td>'.$row['nsdd'].'</td>
      <td>'.$row['exclosuredate'].'</td>
      <td>$row[amount]</td>
      <td>$row[status]</td>
     <td>
     <div class="dropdown">
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
            Actions
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
            <li><a class="dropdown-item" href="./createnwepotentials.php?status=edit&id='.$row['appid'].'">Edit Potentials</a></li>
            <li><a class="dropdown-item" href="#">Add Conversation</a></li>
        </ul>
        </div>
    </td>
   
    </tr>';
    }
    ?>
  </tbody>
</table>
</div>

   </div>

</div>
</section>


<footer class="foot">
<h5>2022 @ KBN CRM</h5>
<h5>kbnsoftwarepvt@gmail.com</h5>
</footer>


<script>

$(".navigation li").hover(function() {
  var isHovered = $(this).is(":hover");
  if (isHovered) {
    $(this).children("ul").stop().slideDown(300);
  } else {
    $(this).children("ul").stop().slideUp(300);
  }
});


</script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>