<?php include '../assets/partials/_dbconnect.php'; ?>
<?php include '../assets/partials/_headers.php'; ?>
<section class="section">
<?php
if(isset($_GET['alert'])){
    echo '   <div style="z-index:0;" class="alert alert-success alert-dismissible fade show" role="alert">
    <strong></strong> '.$_GET['alert'].'
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}
?>


<?php

if (isset($_GET['id']) && $_GET['status'] == 'edit' || $_GET['status'] == 'show') {
  
  
  $id = $_GET['id'];
  $sql = "select * from customer where custId = '$id'";
  $result = mysqli_query($conn, $sql);
  
  while ($row = mysqli_fetch_assoc($result)) {
    
  $accname = $row['accname'];
  $accsize = $row['accsize'];
  $acctype = $row['natureOfBusiness'];
  $bln = $row['bln'];
  $bweb = $row['bweb'];
  $btype = $row['btype'];
  $empsize = $row['empsize'];
  $annrev = $row['annrev'];
  $addinfo = $row['address'];
  $city = $row['district'];
  $state = $row['state'];
  $pincode = $row['zipCode'];
  $csname = $row['name'];
  $csemail = $row['email'];
  $csnumber = $row['contact'];
  $cdesignation = $row['designation'];
  $ctype = $row['ctype'];
  
  }
}
else{

  $accname = "";
  $accsize = "select from the list";
  $acctype = "select from the list";
  $bln = "";
  $bweb = "";
  $btype = "";
  $empsize = "select from the list";
  $annrev ="select from the list";
  $addinfo = "";
  $city = "";
  $state = "";
  $pincode = "";
  $csname = "";
  $csemail = "";
  $csnumber = "";
  $cdesignation = "";
  $ctype = "select from the list";
  
}


?>
  <form action="/crm2/assets/partials/_setQueries.php?t=c" method="POST" >

<?php

if (isset($_GET['id'])) {
  echo '
  <div class="mb-3 form-input">
                <input type="text" id="id" name="id" value="'.  $_GET['id'].'" hidden>
            </div>
  
  
  ';
}
  ?>
  <input type="text" id="state" name="status" value="'. $_GET["status"] .'" hidden>
  <div class="sector3">
<div class="head2 d-flex justify-content-between shadow">
      <p>Create new account</p>
      <a href="./manageacc.php"><p class="btn btn-primary"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
      </svg> Back to accounts</p></a>
  </div> 

  <div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item my-3">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        Account information
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">
      <div class="row">
        <div class="col-md-3">  
            <div class="mb-3 form-input">
                <label for="exampleInputEmail1" class="form-label">Account name</label>
                <input type="text" class="form-control" value="<?php echo $accname; ?>" id="exampleInputEmail1" name="accname" aria-describedby="emailHelp">
            </div>
        </div>
        <div class="col-md-3">  
            <div class="mb-3 form-input">
                <label for="exampleInputEmail1" class="form-label">Account size</label>
                <select class="form-select" name="accsize" value="<?php echo $accsize; ?>" aria-label="Default select example">
                  <option value="Enterprise">Enterprise</option>
                  <option value="SME">SME</option>
                  <option value="MSME">MSME</option>
              </select>            
            </div>
        </div>
        <div class="col-md-3">
        <div class="mb-3 form-input">
          <label for="exampleInputEmail1" class="form-label">Account type</label>
          <select class="form-select" name="acctype" value="<?php echo $acctype; ?>" aria-label="Default select example">
              <option value="Manufacturer">Manufacturer</option>
              <option value="Trading">Trading</option>
              <option value="Retailer">Retailer</option>
              <option value="Partners">Partners</option>
              <option value="others">others</option>
          </select>    
        </div>
        </div>
        <div class="col-md-3">  
            <div class="mb-3 form-input">
                <label for="exampleInputEmail1" class="form-label">Business landline No.</label>
                <input type="text" class="form-control" value="<?php echo $bln; ?>" id="exampleInputEmail1" name="bln" aria-describedby="emailHelp">
            </div>
        </div>
    </div>
      <div class="row">
        <div class="col-md-3">  
            <div class="mb-3 form-input">
                <label for="exampleInputEmail1" class="form-label">Business Website</label>
                <input type="text" class="form-control" value="<?php echo $bweb; ?>" id="exampleInputEmail1" name="bweb" aria-describedby="emailHelp">
            </div>
        </div>
        <div class="col-md-3">
            <div class="mb-3 form-input">
        <label for="exampleInputEmail1" class="form-label">Business Type</label>
        <input type="text" class="form-control" value="<?php echo $btype; ?>" id="exampleInputEmail1" name="btype" aria-describedby="emailHelp">

        
            </div>
        </div>
        <div class="col-md-3">
            <div class="mb-3 form-input">
        <label for="exampleInputEmail1" class="form-label">Employee Size</label>

        <select class="form-select" name="empsize" value="<?php echo $empsize; ?>" aria-label="Default select example">
            <option value="0 - 50">0 - 50</option>
            <option value="51 - 100">51 - 100</option>
            <option value="101 - 200">101 - 200</option>
            <option value="201 - 500">201 - 500</option>
            <option value="500+">500+</option>
         
        </select>
            </div>
        </div>
        <div class="col-md-3">
            <div class="mb-3 form-input">
        <label for="exampleInputEmail1" class="form-label">Annual revenue</label>

        <select class="form-select" name="annrev" value="<?php echo $annrev; ?>" aria-label="Default select example">
            <option value="0 - 50cr">0 - 50cr</option>
            <option value="50 - 100cr">50 - 100cr</option>
            <option value="100 - 300cr">100 - 300cr</option>
            <option value="300 - 500cr">300 - 500cr</option>
            <option value="500cr+">500cr+</option>
            
        </select>
            </div>
        </div>
    </div>
      </div>
    </div>
  </div>
  <div class="accordion-item my-3">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
        Address information
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">
        <div class="row">
            <div class="col-md-3">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Address</label>
                    <input type="text" class="form-control" value="<?php echo $addinfo; ?>" name="addinfo" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="col-md-3">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">City</label>
                    <input type="text" class="form-control" value="<?php echo $city; ?>" name="city" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="col-md-3">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">State</label>
                    <input type="text" class="form-control" name="state" value="<?php echo $state; ?>" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="col-md-3">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Pincode</label>
                    <input type="text" class="form-control" name="pincode" value="<?php echo $pincode; ?>" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>
  <div class="accordion-item my-3">
    <h2 class="accordion-header" id="flush-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
        Account description
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Placeholder content for this accordion, which is intended to demonstrate the <code>.accordion-flush</code> class. This is the third item's accordion body. Nothing more exciting happening here in terms of content, but just filling up the space to make it look, at least at first glance, a bit more representative of how this would look in a real-world application.</div>
    </div>
  </div>
 

 
  
  <div class="accordion-item my-3">
    <h2 class="accordion-header" id="flush-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSeven" aria-expanded="false" aria-controls="flush-collapseThree">
        Contact information
      </button>
    </h2>
    <div id="flush-collapseSeven" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">
        <div class="row">
            <div class="col-md-3">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Contact name</label>
                    <input type="text" class="form-control" value="<?php echo $csname; ?>" id="exampleInputEmail1" name="csname" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="col-md-3">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Contact email</label>
                    <input type="text" class="form-control" value="<?php echo $csemail; ?>" id="exampleInputEmail1" name="csemail" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="col-md-3">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Contact number</label>
                    <input type="text" class="form-control" value="<?php echo $csnumber; ?>" id="exampleInputEmail1" name="csnumber" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="col-md-3">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Contact designation</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo $cdesignation; ?>" name="cdesignation" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="col-md-3">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Contact type</label>
                    <select class="form-select" name="ctype" value="<?php echo $ctype; ?>" aria-label="Default select example">
                      <option value="Influencer">Influencer</option>
                      <option value="Decision Maker">Decision Maker</option>
                      <option value="Messenger">Messenger</option>
                      <option value="Others">Others</option>
                    </select>                
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>

</div>
  <?php 

if ($_GET['status'] == "edit") {
    
echo '
<div class="buttons d-flex justify-content-center">
    <button class="btn btn-primary type="submit" my-2 mx-2">Save</button>
    <div class="btn btn-danger my-2 mx-2">Cancel</div>
</div>';

}
elseif ($_GET['status'] == "new") {
echo '
<div class="buttons d-flex justify-content-center">
    <button type="submit" class="btn btn-primary my-2 mx-2" >Submit</button>
    <div class="btn btn-danger my-2 mx-2">Cancel</div>
</div>';

}
?>

    </form>





    </section>
 
    <footer class="foot">
    <h5>2022 @ KBN CRM</h5>
    <h5>kbnsoftwarepvt@gmail.com</h5>
    </footer>


<script>

$(".navigation li").hover(function() {
  var isHovered = $(this).is(":hover");
  if (isHovered) {
    $(this).children("ul").stop().slideDown(300);
  } else {
    $(this).children("ul").stop().slideUp(300);
  }
});


</script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>