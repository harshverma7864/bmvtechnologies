

<?php include '../assets/partials/_headers.php'; ?>



<section class="section">
    <div class="section1">
    <div class="sector sector1">
        <h5><svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
</svg> Partner Potential Statistics - current month</h5>
<div class="sector1main">
<div class="row">
    <div class="col-md-3 cols text-danger"><p><strong>Potentials</strong></p> <p>0</p></div>
    <div class="col-md-3 cols text-success"><p><strong>Proposal Submitted</strong></p> <p >0</p></div>
    <div class="col-md-3 cols text-success"><p><strong>Potentials won</strong></p> <p >0</p></div>
    <div class="col-md-3 cols value"><p><strong>Value</strong></p> <p ></p></div>
</div>
</div>
    </div>
    <div class="sector sector2">
    <h5><svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
</svg> Partner Potential Statistics - Total</h5>

<div class="sector1main">
<div class="row">
    <div class="col-md-3 cols text-danger"><p><strong>Potentials</strong></p> <p>7</p></div>
    <div class="col-md-3 cols text-success"><p><strong>Proposal Submitted</strong></p> <p >3</p></div>
    <div class="col-md-3 cols text-success"><p><strong>Potentials won</strong></p> <p >0</p></div>
    <div class="col-md-3 cols value"><p><strong>Value</strong></p> <p >INR 1,850,000</p></div>
</div>
</div>
    </div>
</div>
<footer class="foot">
<h5>2022 @ KBN CRM</h5>
<h5>kbnsoftwarepvt@gmail.com</h5>
</footer>
</section>


<script>

$(".navigation li").hover(function() {
  var isHovered = $(this).is(":hover");
  if (isHovered) {
    $(this).children("ul").stop().slideDown(300);
  } else {
    $(this).children("ul").stop().slideUp(300);
  }
});


</script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>