<?php include '../assets/partials/_dbconnect.php'; ?>
<?php include '../assets/partials/_headers.php'; ?>
<?php include '../assets/partials/_fetchQueries.php'; ?>


<!-- <script>window.localStorage.setItem("ck", "")</script> -->

<!-- <script>window.localStorage.setItem("accname", "")</script> -->
<?php $conn = mysqli_connect("localhost", "root", "", "crmdb"); 

?>


<?php

if (isset($_GET['id']) && $_GET['status'] == 'edit' || $_GET['status'] == 'show') {
  $id = $_GET['id'];
  $sql = "select * from potentials where appid = '$id'";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);

  $mksource = $row['mksource'];
  $saccname = $row['accname'];
  $contperson  = $row['contperson'];
  $rank  = $row['rank'];
  $potname = $row['potname'];
  $estdealvalue = $row['estdealvalue'];
  $exclosuredate = $row['exclosuredate'];
  $parentcat = $row['parentcat'];
  $product = $row['product'];
  $nsdd = $row['nsdd'];
  $NOT = $row['NOT'];
  $bvertical = $row['bvertical'];
  $region = $row['region'];
  $state = $row['state'];
  $city = $row['city'];
  $requirements = $row['requirements'];
}
else{


  $mksource = "";
  $saccname  = "select from the list";
  $contperson  = "";
  $rank  ="";
  $potname = "";
  $estdealvalue = "";
  $exclosuredate = "dd/mm/yyyy";
  $parentcat = "select from the list";
  $product = "select from the list";
  $nsdd = "";
  $NOT = "select from the list";
  $bvertical = "select from the list";
  $region = "select from the list";
  $state = "select from the list";
  $city = "select from the list";
  $requirements = "";
}


?>




<section class="section">
<form action="/crm2/assets/partials/_setQueries.php?t=p" method="POST">
<input type="text" name="state" value="<?php echo $_GET['status']; ?>">
<div class="sector3">
<div class="head2 d-flex justfy-content-between shadow">
      <p>Add new potential</p>
      <a href="./managepotentials.php"><p class="btn btn-primary"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
      </svg> Back to Potentials</p></a>
  </div> 

  <div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item my-3">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        Source Info
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">
      <div class="row">
     
        <div class="col-md-3">  
            <div class="mb-3 form-input">
                <label for="exampleInputEmail1" class="form-label">Marketing Source</label>
                <select class="form-select" value = "<?php echo $mksource; ?>" name="mksource" aria-label="Default select example">
            <option value="Website Enquiry">Website Enquiry</option>
            <option value="Facebook">Facebook</option>
            <option value="Email Campaign">Email Campaign</option>
            <option value="Whatsapp">Whatsapp</option>
            <option value="ISS">ISS</option>
            <option value="Linkedin">Linkedin</option>
            <option value="Twitter">Twitter</option>
            <option value="SMS Campaign">SMS Campaign</option>
            <option value="Event/Conference">Event/Conference</option>
            <option value="Print Ad">Print Ad</option>
            <option value="Cold call">Cold call</option>
            <option value="Others">Others</option>
            <option value="Chat">Chat</option>
            
        </select>            </div>
        </div>
        <div class="col-md-3">  
            <div class="mb-3 form-input">
                <label for="exampleInputEmail1" class="form-label">Account Name</label>
                <select class="form-select" value = "<?php echo $saccname; ?>" id="accname" onchange="" name="saccname" aria-label="Default select example" >
                  <?php 
                  
                $result = getCustomerData($conn);
                while ($row = mysqli_fetch_assoc($result) ) {
                  echo '
                  
                  <option value="'.$row['accname'].'">'.$row['accname'].'</option>';
                }
            ?>
        </select>
            </div>
        </div>

      


        <script>

        // var fillcookie = function(){
          
        //   console.log("  ")

        //   var ck = document.getElementById("accname").value;
        //   console.log(ck);
         
        //   <?php

        //   echo '<script type="text/javascript">' .
        //   'console.log("hehhdksjk");</script>';
        //   // $a = "</script> console.log(ck);</script>";
        //   // echo $a;
        //   ?> 

         
        // }
        </script>
        
        <div class="col-md-3">
            <div class="mb-3 form-input">
        <label for="exampleInputEmail1" class="form-label">Contact Person</label>
        <input type="text" class="form-control" id="exampleInputEmail1" value = "<?php echo $contperson; ?>" name="contperson" aria-describedby="emailHelp">

        
            </div>
        </div>
        <div class="col-md-3">
            <div class="mb-3 form-input">
        <label for="exampleInputEmail1"  class="form-label">Rank</label>

        <select class="form-select" name="rank" aria-label="Default select example">
            <option value="Hot">Hot</option>
            <option value="Warm">Warm</option>
            <option value="Cold">Cold</option>
            
        </select>
            </div>
        </div>
        </div>
    
       
        
    </div>
      </div>
    </div>
  </div>
  <div class="accordion-item my-3">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
        Potentials Details
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">
        <div class="row">
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Potential Name</label>
                    <input type="text" class="form-control" value = "<?php echo $potname; ?>" id="exampleInputEmail1" name="potname" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Estimated Deal Value</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" value = "<?php echo $estdealvalue; ?>" name="estdealvalue" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Expected Closure Date</label>
                    <input type="date" class="form-control" id="exampleInputEmail1" value = "<?php echo $exclosuredate; ?>" name="exclosuredate" aria-describedby="emailHelp">
                </div>
            </div>
            <hr>
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Parent Category</label>
                    <select class="form-select" name="parentcat" value = "<?php echo $parentcat; ?>" aria-label="Default select example">
            <option value="UdyogERP">UdyogERP</option>
            <option value="uBooks">uBooks</option>
            <option value="uBook360">uBook360</option>
            <option value="Surefile">Surefile</option>
            <option value="Tracet">Tracet</option>
            <option value="ListAny">ListAny</option>
            <option value="E-Invoice">E-Invoice</option>
        
        </select>
                </div>
            </div>
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Choose Product</label>
                    <select class="form-select" name="product" value = "<?php echo $product; ?>" aria-label="Default select example">
            <option value="1">One</option>
       
        </select>
                </div>
            </div>
            <hr>
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Next Step Due Date</label>
                    <input type="date" class="form-control" name="nsdd" value = "<?php echo $nsdd; ?>" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
            </div>
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Number of transactions</label>
                    <select class="form-select" name="NOT" value = "<?php echo $NOT; ?>" aria-label="Default select example">
                      <option value="0 - 20000">0 - 20000</option>
                      <option value="20000 - 40000">20000 - 40000</option>
                      <option value="40000 +">40000 +</option>
                  </select>
                </div>
            </div>
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Business Vertical</label>
                    <select class="form-select" name="bvertical" value = "<?php echo $bvertical; ?>" aria-label="Default select example">
                      <option value="Metal & Alloys">Metal & Alloys</option>
                      <option value="Pharma & Chemicals">Pharma & Chemicals</option>
                      <option value="Plastic Industries">Plastic Industries</option>
                      <option value="Software">Software</option>
                      <option value="Electrical Industries">Electrical Industries</option>
                      <option value="Automobile">Automobile</option>
                      <option value="packaging">packaging</option>
                      <option value="Clothing">Clothing</option>
                      <option value="Food Industry">Food Industry</option>
                      <option value="Paper Industry">Paper Industry</option>
                      <option value="Construction company">Construction company</option>
                      <option value="Paints">Paints</option>
                      <option value="Rubber">Rubber</option>
                      <option value="Bank">Bank</option>
                      <option value="Electronics">Electronics</option>
                      <option value="Logistics">Logistics</option>
                      <option value="Hotels">Hotels</option>
                      <option value="Glass Industry">Glass Industry</option>
                      <option value="Printing">Printing</option>
                      <option value="Institutions">Institutions</option>
                      <option value="Marbel">Marbel</option>
                      <option value="Transport">Transport</option>
                      <option value="Electronic Industries">Electronic Industries</option>
                      <option value="Others">Others</option>
                      <option value="Gems & Jwellery">Gems & Jwellery</option>
                 
                  </select>
                </div>
            </div>
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Select Region</label>
                    <select class="form-select" name="region" value = "<?php echo $region; ?>" aria-label="Default select example">
                      <option value="East">East</option>
                      <option value="West">West</option>
                      <option value="North">North</option>
                      <option value="South">South</option>
                  
                  </select>
                </div>
            </div>
            <div class="col-md-4"> 
               
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Select State</label>
                    <select class="form-select state" value = "<?php echo $state; ?>" onChange="setstate();" id="state" name="state" aria-label="Default select example">
                      <?php 
                     
                      $sql = "select * from statemaster2";
                      $result = mysqli_query($conn, $sql);
                      while ($row = mysqli_fetch_assoc($result)) {
                        echo '<option value="'.$row['S_ID'].'">'.$row['STATE'].'</option >';
                      }
                      
                      ?>
                      
                      
                  </select>

                  <script>
                    var setstate = function(){
                        var a = document.getElementById('state').value;
                        window.localStorage.setItem('ck', a);
                    }
                  </script>


                </div>
            </div>
            <div class="col-md-4">  
                <div class="mb-3 form-input">
                    <label for="exampleInputEmail1" class="form-label">Select City</label>
                    <select class="form-select" name="city" value = "<?php echo $city; ?>" aria-label="Default select example">
                      <?php
                       
            
                       $a = "<script>console.log((window.localStorage.getItem('ck')))</script>";
                       echo $a;
                      $sql2 = "select * from distmaster where S_ID = '$a'";
                      $result2 = mysqli_query($conn, $sql2);
                      while ($row2 = mysqli_fetch_assoc($result2)) {
                        echo '<option value="'.$row2['CODE'].'">'.$a.'</option>';
                      }
                      
                      ?>
                      
                  </select>
                </div>
            </div>
            <div class="mb-3 col-md-12">
              <label for="exampleFormControlTextarea1" class="form-label">Business Requirements</label>
              <textarea class="form-control" name="requirements" id="exampleFormControlTextarea1" value = "<?php echo $requirements; ?>" rows="3"></textarea>
            </div>
        </div>
      </div>
    </div>
  </div>

</div>


<?php

if ($_GET['status'] == "edit") {
  
  echo 
  '
  <div class="buttons d-flex justify-content-center">
    <button type="submit" class="btn btn-primary my-2 mx-2">Save</button>
    <div class="btn btn-danger my-2 mx-2">Cancel</div>
</div>';
}

elseif ($_GET['status'] == "new") {
  echo 
  '
  <div class="buttons d-flex justify-content-center">
    <button class="btn btn-primary my-2 mx-2" type="submit">Submit</button>
    <div class="btn btn-danger my-2 mx-2">Cancel</div>
</div>';
}


?>
</form>
    </section>
    <footer class="foot">
    <h5>2022 @ KBN CRM</h5>
    <h5>kbnsoftwarepvt@gmail.com</h5>
    </footer>

    


<script>






function mainInfo(id) {

    $.ajax({
        type: "GET",
        url: "/crm2/pages/createnwepotentials.php",
        data: "mainid =" + id,
        success: function(result) {
            $("#somewhere").html(result);
        }
    });
    
};

$(".navigation li").hover(function() {
  var isHovered = $(this).is(":hover");
  if (isHovered) {
    $(this).children("ul").stop().slideDown(300);
  } else {
    $(this).children("ul").stop().slideUp(300);
  }
});


</script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>