<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="../bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>
    <title>CRM</title>
  </head>
  <body>
    
<div class="main">



  <img src="../assets/img/user.jpg" alt="user image" class="userimg">
  <div class="userInfoCard"></div>
    <div class="cards">
        <div class="card" onClick= 'location.href = "/crm2/pages/preapp.php"' id="card1">
          <img src="../assets/img/preapp.png" alt="">
          <h5 class="text-center">Pre Approval</h5>
        </div>
        <div class="card " id="card2">
        <h5 class="text-center">Post Approval</h5>
        </div>
    </div>
</div>

<script>
  $(".card").hover(function(){
     $(".card").addClass("shadow-lg")
  },function(){
    $(".card").removeClass("shadow-lg")
  })

$(".userimg").hover(function(){
   $(".userInfoCard").css("visibility", "visible")
   $(".userInfoCard").css("height", "50vh")
   $(".userInfoCard").css("width", "30vw")
}, function(){
  $(".userInfoCard").css("visibility", "hidden")
  $(".userInfoCard").css("height", "0vh")
  $(".userInfoCard").css("width", "0vw")

})

</script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>